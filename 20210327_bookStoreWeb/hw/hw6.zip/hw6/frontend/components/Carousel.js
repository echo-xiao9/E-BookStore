import '../css/Carousel.css';

function Carousel() {
    return (
        <div className="container" id="Carousel">
            <div className="carousel">
                <div className="carousel__face"><span></span></div>
                <div className="carousel__face"><span></span></div>
                <div className="carousel__face"><span></span></div>
                <div className="carousel__face"><span></span></div>
                <div className="carousel__face"><span></span></div>
                <div className="carousel__face"><span></span></div>

            </div>
        </div>
    );
}

export default Carousel;