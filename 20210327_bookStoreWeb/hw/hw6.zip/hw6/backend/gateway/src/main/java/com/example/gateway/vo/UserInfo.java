package com.example.gateway.vo;

import lombok.Data;

@Data
public class UserInfo {
    private String username;
    private String userRole;
}
