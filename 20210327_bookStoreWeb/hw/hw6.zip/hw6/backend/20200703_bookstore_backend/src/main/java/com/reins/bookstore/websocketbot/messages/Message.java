package com.reins.bookstore.websocketbot.messages;public class Message {
}
