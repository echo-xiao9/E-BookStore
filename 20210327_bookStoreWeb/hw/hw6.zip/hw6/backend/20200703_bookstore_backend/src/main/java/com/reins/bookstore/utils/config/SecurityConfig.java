package com.reins.bookstore.utils.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
