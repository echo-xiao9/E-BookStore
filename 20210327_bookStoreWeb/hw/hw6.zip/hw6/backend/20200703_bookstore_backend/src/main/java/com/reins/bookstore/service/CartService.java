package com.reins.bookstore.service;

import com.reins.bookstore.entity.Cart;
import org.springframework.context.annotation.Scope;

import java.util.List;

public interface CartService {
//    List<Cart> getCart();

    List<Cart> clearCart(Integer userId);

    Cart addToCart(String name, String author, Integer price, Integer number,Integer bookId, Integer userId);

    List<Cart> getUserCart(Integer userId);
}
